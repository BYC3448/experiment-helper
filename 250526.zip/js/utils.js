// utils.js - 긴급 수정 버전 (드롭다운 안전)

// 템플릿 문자열에 변수 삽입하는 함수
export function renderTemplate(template, variables) {
    return template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
        return variables[key] !== undefined ? variables[key] : match;
    });
}

// 선수학습 내용을 텍스트로 포매팅하는 함수
export function formatPrerequisiteContent(prerequisites) {
    if (!prerequisites || prerequisites.length === 0) {
        return "선수학습 내용이 없습니다.";
    }

    let result = "";
    const grouped = {};
    
    // 학교급별로 그룹화
    prerequisites.forEach(pre => {
        if (!grouped[pre.schoolLevel]) {
            grouped[pre.schoolLevel] = {};
        }
        
        if (!grouped[pre.schoolLevel][pre.gradeGroup]) {
            grouped[pre.schoolLevel][pre.gradeGroup] = {};
        }
        
        if (!grouped[pre.schoolLevel][pre.gradeGroup][pre.subject]) {
            grouped[pre.schoolLevel][pre.gradeGroup][pre.subject] = {};
        }
        
        grouped[pre.schoolLevel][pre.gradeGroup][pre.subject][pre.unit] = pre.contentElements;
    });
    
    // 그룹화된 데이터를 텍스트로 변환
    for (const schoolLevel in grouped) {
        for (const gradeGroup in grouped[schoolLevel]) {
            result += `- ${schoolLevel} ${gradeGroup}:\n`;
            
            for (const subject in grouped[schoolLevel][gradeGroup]) {
                for (const unit in grouped[schoolLevel][gradeGroup][subject]) {
                    const elements = grouped[schoolLevel][gradeGroup][subject][unit];
                    result += `  - ${unit}: ${elements.join(', ')}\n`;
                }
            }
        }
    }
    
    return result;
}

// PDF 읽기 함수
async function readPdfFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = async (e) => {
            try {
                const typedarray = new Uint8Array(e.target.result);
                const pdf = await pdfjsLib.getDocument(typedarray).promise;
                let text = '';
                
                for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
                    const page = await pdf.getPage(pageNum);
                    const content = await page.getTextContent();
                    const pageText = content.items.map(item => item.str).join(' ');
                    text += pageText + '\n';
                }
                
                resolve(text);
            } catch (error) {
                reject(error);
            }
        };
        
        reader.onerror = () => reject(reader.error);
        reader.readAsArrayBuffer(file);
    });
}

// DOCX 읽기 함수
async function readDocxFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = async (e) => {
            try {
                const arrayBuffer = e.target.result;
                const result = await mammoth.extractRawText({arrayBuffer: arrayBuffer});
                resolve(result.value);
            } catch (error) {
                reject(error);
            }
        };
        
        reader.onerror = () => reject(reader.error);
        reader.readAsArrayBuffer(file);
    });
}

// 일반 텍스트 파일 읽기 함수
async function readTextFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        
        reader.onload = (event) => {
            resolve(event.target.result);
        };
        
        reader.onerror = (error) => {
            reject(error);
        };
        
        reader.readAsText(file);
    });
}

// 파일 내용 읽기 함수 (통합된 버전)
export async function readFileContent(file) {
    const fileType = file.name.split('.').pop().toLowerCase();
    
    try {
        switch (fileType) {
            case 'pdf':
                return await readPdfFile(file);
                
            case 'docx':
                return await readDocxFile(file);
                
            case 'txt':
            case 'md':
            default:
                return await readTextFile(file);
        }
    } catch (error) {
        console.error('파일 읽기 오류:', error);
        throw new Error(`${fileType.toUpperCase()} 파일 읽기 중 오류가 발생했습니다: ${error.message}`);
    }
}

// 텍스트를 클립보드에 복사하는 함수 (백업용으로 유지)
export async function copyToClipboard(text) {
    try {
        await navigator.clipboard.writeText(text);
        return true;
    } catch (err) {
        console.error('클립보드 복사 오류:', err);
        return false;
    }
}

// HTML 파일로 다운로드하는 함수 (Word에서 열 수 있음)
export async function downloadAsDocx(content, filename) {
    try {
        // 마크다운을 HTML로 변환
        const htmlContent = markdownToWordHtml(content);
        
        // Word에서 열 수 있는 HTML 형식으로 생성
        const fullHtml = `<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="ProgId" content="Word.Document">
    <meta name="Generator" content="Microsoft Word 15">
    <title>${filename}</title>
    <style type="text/css">
        body { font-family: '맑은 고딕', Arial, sans-serif; font-size: 12pt; line-height: 1.6; margin: 2cm; }
        h1 { font-size: 18pt; font-weight: bold; margin-top: 20pt; margin-bottom: 10pt; }
        h2 { font-size: 16pt; font-weight: bold; margin-top: 15pt; margin-bottom: 8pt; }
        h3 { font-size: 14pt; font-weight: bold; margin-top: 12pt; margin-bottom: 6pt; }
        p { margin-top: 6pt; margin-bottom: 6pt; }
        ul { margin-left: 20pt; }
        li { margin-bottom: 3pt; }
        strong { font-weight: bold; }
        em { font-style: italic; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; }
        th, td { border: 1px solid #333; padding: 8px; text-align: center; }
        th { background-color: #f0f0f0; font-weight: bold; }
    </style>
</head>
<body>
${htmlContent}
</body>
</html>`;
        
        // Blob 생성
        const blob = new Blob([fullHtml], { 
            type: 'application/msword'
        });
        
        // 다운로드 실행 (.doc 확장자 사용)
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${filename}.doc`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        return true;
    } catch (error) {
        console.error('HTML 다운로드 오류:', error);
        throw new Error(`파일 생성 중 오류가 발생했습니다: ${error.message}`);
    }
}

// 마크다운을 Word용 HTML로 변환하는 함수
function markdownToWordHtml(markdown) {
    if (!markdown) return '';
    
    return markdown
        .replace(/^### (.*$)/gm, '<h3>$1</h3>')
        .replace(/^## (.*$)/gm, '<h2>$1</h2>')
        .replace(/^# (.*$)/gm, '<h1>$1</h1>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/^- (.*$)/gm, '<li>$1</li>')
        .replace(/(<li>.*<\/li>\s*)+/g, '<ul>$&</ul>')
        .replace(/<\/ul>\s*<ul>/g, '')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>')
        .replace(/^(.)/gm, '<p>$1')
        .replace(/(.)$/gm, '$1</p>')
        .replace(/<p><h/g, '<h')
        .replace(/<\/h([1-6])><\/p>/g, '</h$1>')
        .replace(/<p><ul>/g, '<ul>')
        .replace(/<\/ul><\/p>/g, '</ul>');
}

// 디버그 로그 함수
export function debug(message, data) {
    if (window.APP_CONFIG?.debugMode) {
        console.log(`[DEBUG] ${message}`, data);
    }
}

// 에러 메시지 표시 함수
export function showErrorMessage(message) {
    alert(message);
}

// 마크다운을 HTML로 변환하는 함수 (기존 기능 유지)
export function markdownToHtml(markdown) {
    if (!markdown) return '';
    
    // HTML 코드 블록 처리 (```html ... ``` 제거하고 내용만 렌더링)
    let html = markdown.replace(/```html\s*\n(.*?)\n```/gs, '$1');
    
    // 일반 코드 블록도 처리 (```...``` 제거)
    html = html.replace(/```[\s\S]*?```/g, '');
    
    // 과도한 줄바꿈 정리 (3개 이상의 연속 줄바꿈을 2개로)
    html = html.replace(/\n{3,}/g, '\n\n');
    
    // 간단한 마크다운 변환
    return html
        .replace(/^### (.*$)/gm, '<h3>$1</h3>')
        .replace(/^## (.*$)/gm, '<h2>$1</h2>')
        .replace(/^# (.*$)/gm, '<h1>$1</h1>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/^- (.*$)/gm, '<li>$1</li>')
        .replace(/(<li>.*<\/li>)/gm, '<ul>$1</ul>')
        .replace(/<\/ul>\s*<ul>/g, '')
        .replace(/\n\n/g, '</p><p>')
        .replace(/\n/g, '<br>')
        .replace(/^(.)/gm, '<p>$1')
        .replace(/(.)$/gm, '$1</p>')
        .replace(/<p><h/g, '<h')
        .replace(/<\/h([1-6])><\/p>/g, '</h$1>')
        .replace(/<p><ul>/g, '<ul>')
        .replace(/<\/ul><\/p>/g, '</ul>')
        .replace(/<p><table>/g, '<table>')
        .replace(/<\/table><\/p>/g, '</table>');
}