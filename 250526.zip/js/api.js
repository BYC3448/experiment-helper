// api.js

import config from './config.js';

// 스트리밍 방식으로 OpenAI API 호출
async function callOpenAIWithStreaming(messages, onChunk) {
    try {
        const response = await fetch(config.apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${config.apiKey}`
            },
            body: JSON.stringify({
                model: config.apiModel,
                messages: messages,
                max_tokens: config.maxTokens,
                temperature: config.temperature,
                stream: true
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`API 오류: ${response.status} - ${errorText}`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        let fullText = '';

        while (true) {
            const { value, done } = await reader.read();

            if (done) {
                if (buffer.length > 0) {
                    const line = buffer.trim();
                    if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                        try {
                            const jsonData = line.substring(6).trim();
                            if (jsonData.length > 0) {
                                const data = JSON.parse(jsonData);
                                const content = data.choices[0]?.delta?.content || '';
                                if (content) {
                                    fullText += content;
                                    if (typeof onChunk === 'function') {
                                        onChunk(content, fullText);
                                    }
                                }
                            }
                        } catch (e) {
                            console.warn('스트리밍 파싱 오류 (잔여 데이터 처리 중):', e, "Problematic JSON string:", line.substring(6));
                        }
                    }
                }
                break;
            }

            buffer += decoder.decode(value, { stream: true });

            let newlineIndex;
            while ((newlineIndex = buffer.indexOf('\n')) >= 0) {
                const line = buffer.substring(0, newlineIndex).trim();
                buffer = buffer.substring(newlineIndex + 1);

                if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                    try {
                        const jsonData = line.substring(6).trim();
                        if (jsonData.length > 0) {
                            const data = JSON.parse(jsonData);
                            const content = data.choices[0]?.delta?.content || '';
                            if (content) {
                                fullText += content;
                                if (typeof onChunk === 'function') {
                                    onChunk(content, fullText);
                                }
                            }
                        }
                    } catch (parseError) {
                        console.warn('스트리밍 파싱 오류:', parseError, 'Problematic line content:', line);
                    }
                } else if (line === 'data: [DONE]') {
                    // This indicates the logical end of the stream content.
                    // The `done` flag from reader.read() will physically close the loop.
                }
            }
        }
        
        return fullText;
    } catch (error) {
        console.error("API 호출 오류:", error);
        throw error;
    }
}

// 일반 방식으로 OpenAI API 호출 (백업용)
async function callOpenAI(messages) {
    try {
        const response = await fetch(config.apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${config.apiKey}`
            },
            body: JSON.stringify({
                model: config.apiModel,
                messages: messages,
                max_tokens: config.maxTokens,
                temperature: config.temperature
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`API 오류: ${response.status} - ${errorText}`);
        }

        const data = await response.json();
        return data.choices[0].message.content;
    } catch (error) {
        console.error("API 호출 오류:", error);
        throw error;
    }
}

// 환경에 따른 적절한 호출 방식 선택
export async function callOpenAIService(messages, onChunk = null) {
    if (!config.apiKey || config.apiKey === 'sk-your_api_key_here') {
        throw new Error('OpenAI API key가 설정되지 않았습니다.');
    }

    if (config.useStreaming && onChunk && typeof onChunk === 'function') {
        return callOpenAIWithStreaming(messages, onChunk);
    } else {
        return callOpenAI(messages);
    }
}