// app.js (docx 다운로드 기능이 추가된 최종 버전)

import { curriculumData, getPrerequisiteContent } from './curriculum.js';
import { experimentDesignPrompt, studentReportTemplatePrompt, experimentRevisionPrompt, simulationPrompt } from './prompts.js';
import config from './config.js';
import { callOpenAIService } from './api.js';
import { 
    renderTemplate, 
    formatPrerequisiteContent, 
    readFileContent, 
    copyToClipboard, 
    downloadAsDocx,
    showErrorMessage, 
    markdownToHtml,
    debug 
} from './utils.js';

// 전역 변수 선언
let state = {
    currentExperiment: null,
    currentReport: null,
    selectedElements: []
};

let youtubeState = {
    currentPage: 1,
    searchResults: [],
    isLoading: false,
    currentFilter: '',
    hasMoreResults: true
};

// 전역 설정을 window에 노출 (디버깅 목적)
window.APP_CONFIG = config;

// 초기화 함수
function init() {
    console.log('App initializing...');
    
    // DOM이 완전히 로드된 후에 실행
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeApp);
    } else {
        initializeApp();
    }
}

function initializeApp() {
    console.log('Initializing app components...');
    debug('Curriculum data', curriculumData);
    
    // 기본 UI 요소 설정
    setupDropdowns();
    setupFileUpload();
    
    // 기본 이벤트 리스너 설정
    setupBasicEventListeners();
    
    console.log('App initialized');
}

// 기본 이벤트 리스너 설정 (항상 존재하는 요소들)
function setupBasicEventListeners() {
    // 폼 제출 이벤트
    const form = document.getElementById('experimentForm');
    if (form) {
        form.addEventListener('submit', handleFormSubmit);
    }
    
    // 탭 이벤트
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabName = btn.dataset.tab;
            activateTab(tabName);
        });
    });
    
    // 모달 닫기 이벤트
    document.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', closeModals);
    });
    
    // 모달 외부 클릭 시 닫기
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModals();
        }
    });
}

// 모달 닫기 함수
function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.style.display = 'none';
    });
}

// 결과 섹션 관련 이벤트 리스너 설정
function setupResultEventListeners() {
    const outputSection = document.getElementById('outputSection');
    if (!outputSection) return;
    
    // 설계안 수정 요청 버튼
    const revisionBtn = document.getElementById('revisionBtn');
    if (revisionBtn) {
        revisionBtn.addEventListener('click', handleRevisionClick);
    }
    
    // 실험 설계안 내보내기 버튼
    const exportExperimentBtn = document.getElementById('exportExperimentBtn');
    if (exportExperimentBtn) {
        exportExperimentBtn.addEventListener('click', () => handleExport('experiment'));
    }
    
    // 보고서 내보내기 버튼
    const exportReportBtn = document.getElementById('exportReportBtn');
    if (exportReportBtn) {
        exportReportBtn.addEventListener('click', () => handleExport('report'));
    }
    
    // 수정 요청 제출 버튼
    const submitRevisionBtn = document.getElementById('submitRevisionBtn');
    if (submitRevisionBtn) {
        submitRevisionBtn.addEventListener('click', handleSubmitRevision);
    }
    
    // YouTube 검색 관련 이벤트
    const applyFilterBtn = document.getElementById('applyFilter');
    if (applyFilterBtn) {
        applyFilterBtn.addEventListener('click', handleFilterApply);
    }
    
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', handleLoadMore);
    }
}

// 드롭다운 설정
function setupDropdowns() {
    const schoolLevel = document.getElementById('schoolLevel');
    const gradeGroup = document.getElementById('gradeGroup');
    const subject = document.getElementById('subject');
    const unit = document.getElementById('unit');
    
    console.log('Setting up dropdowns. SchoolLevel element:', schoolLevel);
    
    // 학교급 초기화
    schoolLevel.innerHTML = '<option value="" disabled selected>학교급 선택</option>';
    Object.keys(curriculumData).forEach(school => {
        const option = document.createElement('option');
        option.value = school;
        option.textContent = school;
        schoolLevel.appendChild(option);
    });
    
    console.log('School levels loaded. Total:', schoolLevel.options.length);
    
    // 학교급 변경 이벤트
    schoolLevel.addEventListener('change', function() {
        console.log('School level changed to:', this.value);
        const selectedSchool = this.value;
        
        gradeGroup.innerHTML = '<option value="" disabled selected>학년군 선택</option>';
        subject.innerHTML = '<option value="" disabled selected>과목 선택</option>';
        unit.innerHTML = '<option value="" disabled selected>단원 선택</option>';
        
        if (selectedSchool && curriculumData[selectedSchool]) {
            Object.keys(curriculumData[selectedSchool]).forEach(grade => {
                const option = document.createElement('option');
                option.value = grade;
                option.textContent = grade;
                gradeGroup.appendChild(option);
            });
            gradeGroup.disabled = false;
        } else {
            gradeGroup.disabled = true;
        }
        subject.disabled = true;
        unit.disabled = true;
        clearContentElements();
    });
    
    // 학년군 변경 이벤트
    gradeGroup.addEventListener('change', function() {
        console.log('Grade group changed to:', this.value);
        const selectedSchool = schoolLevel.value;
        const selectedGrade = this.value;
        
        subject.innerHTML = '<option value="" disabled selected>과목 선택</option>';
        unit.innerHTML = '<option value="" disabled selected>단원 선택</option>';
        
        if (selectedSchool && selectedGrade && curriculumData[selectedSchool][selectedGrade]) {
            Object.keys(curriculumData[selectedSchool][selectedGrade]).forEach(subj => {
                const option = document.createElement('option');
                option.value = subj;
                option.textContent = subj;
                subject.appendChild(option);
            });
            subject.disabled = false;
        } else {
            subject.disabled = true;
        }
        unit.disabled = true;
        clearContentElements();
    });
    
    // 과목 변경 이벤트
    subject.addEventListener('change', function() {
        console.log('Subject changed to:', this.value);
        const selectedSchool = schoolLevel.value;
        const selectedGrade = gradeGroup.value;
        const selectedSubject = this.value;
        
        unit.innerHTML = '<option value="" disabled selected>단원 선택</option>';
        
        if (selectedSchool && selectedGrade && selectedSubject && 
            curriculumData[selectedSchool][selectedGrade][selectedSubject]) {
            Object.keys(curriculumData[selectedSchool][selectedGrade][selectedSubject]).forEach(u => {
                const option = document.createElement('option');
                option.value = u;
                option.textContent = u;
                unit.appendChild(option);
            });
            unit.disabled = false;
        } else {
            unit.disabled = true;
        }
        clearContentElements();
    });
    
    // 단원 변경 이벤트
    unit.addEventListener('change', function() {
        console.log('Unit changed to:', this.value);
        const selectedSchool = schoolLevel.value;
        const selectedGrade = gradeGroup.value;
        const selectedSubject = subject.value;
        const selectedUnit = this.value;
        
        if (selectedSchool && selectedGrade && selectedSubject && selectedUnit) {
            const elements = curriculumData[selectedSchool][selectedGrade][selectedSubject][selectedUnit];
            if (elements) {
                displayContentElements(elements);
            }
        } else {
            clearContentElements();
        }
    });
}

// 내용 요소 표시 함수
function displayContentElements(elements) {
    const container = document.getElementById('contentElements');
    container.innerHTML = '';
    
    elements.forEach(element => {
        const span = document.createElement('span');
        span.className = 'content-element';
        span.textContent = element;
        span.addEventListener('click', function() {
            toggleElementSelection(element, this);
        });
        container.appendChild(span);
    });
}

// 내용 요소 선택/해제 토글
function toggleElementSelection(element, spanElement) {
    const index = state.selectedElements.indexOf(element);
    
    if (index > -1) {
        state.selectedElements.splice(index, 1);
        spanElement.classList.remove('selected');
    } else {
        state.selectedElements.push(element);
        spanElement.classList.add('selected');
    }
    
    updateSelectedElementsDisplay();
}

// 선택된 요소 표시 업데이트
function updateSelectedElementsDisplay() {
    const container = document.getElementById('selectedElements');
    const display = document.getElementById('selectedElementsDisplay');
    
    if (state.selectedElements.length > 0) {
        container.style.display = 'block';
        display.innerHTML = '';
        
        state.selectedElements.forEach(element => {
            const tag = document.createElement('span');
            tag.className = 'selected-element-tag';
            tag.innerHTML = `${element} <span class="remove-btn" onclick="removeSelectedElement('${element.replace(/'/g, "\\'")}')">&times;</span>`;
            display.appendChild(tag);
        });
    } else {
        container.style.display = 'none';
    }
}

// 선택된 요소 제거 함수
window.removeSelectedElement = function(element) {
    const index = state.selectedElements.indexOf(element);
    if (index > -1) {
        state.selectedElements.splice(index, 1);
        updateSelectedElementsDisplay();
        
        // UI 업데이트
        const spans = document.querySelectorAll('.content-element');
        spans.forEach(span => {
            if (span.textContent === element) {
                span.classList.remove('selected');
            }
        });
    }
};

// 내용 요소 초기화
function clearContentElements() {
    const container = document.getElementById('contentElements');
    container.innerHTML = '<p class="placeholder-text">단원을 선택하면 내용 요소가 표시됩니다.</p>';
    state.selectedElements = [];
    updateSelectedElementsDisplay();
}

// 파일 업로드 설정
function setupFileUpload() {
    const fileInput = document.getElementById('referenceFile');
    const fileContainer = fileInput.parentElement;
    const label = fileContainer.querySelector('.file-drop-label');
    
    // 드래그 앤 드롭 이벤트
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileContainer.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        fileContainer.addEventListener(eventName, () => {
            fileContainer.classList.add('drag-over');
        }, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        fileContainer.addEventListener(eventName, () => {
            fileContainer.classList.remove('drag-over');
        }, false);
    });
    
    fileContainer.addEventListener('drop', function(e) {
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            label.textContent = `선택된 파일: ${files[0].name}`;
        }
    }, false);
    
    // 파일 선택 시 레이블 업데이트
    fileInput.addEventListener('change', function() {
        if (this.files && this.files.length > 0) {
            label.textContent = `선택된 파일: ${this.files[0].name}`;
        } else {
            label.textContent = '클릭하거나 파일을 드래그하여 업로드';
        }
    });
}

// 폼 제출 핸들러
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const schoolLevel = document.getElementById('schoolLevel').value;
    const gradeGroup = document.getElementById('gradeGroup').value;
    const subject = document.getElementById('subject').value;
    const unit = document.getElementById('unit').value;
    
    if (!schoolLevel || !gradeGroup || !subject || !unit) {
        showErrorMessage('학교급, 학년군, 과목, 단원을 모두 선택해주세요.');
        return;
    }
    
    if (!config.apiKey || config.apiKey === 'sk-your_api_key_here') {
        showErrorMessage('OpenAI API 키가 설정되지 않았습니다. config.js 파일을 확인해주세요.');
        return;
    }
    
    try {
        showLoading('실험을 설계하는 중입니다...');
        
        // 선수학습 내용 가져오기
        const prerequisites = getPrerequisiteContent(schoolLevel, gradeGroup);
        const prerequisiteContent = formatPrerequisiteContent(prerequisites);
        
        // 내용 요소 가져오기 (선택된 요소가 있으면 그것을 사용)
        let contentElements;
        if (state.selectedElements.length > 0) {
            contentElements = state.selectedElements;
        } else {
            contentElements = curriculumData[schoolLevel][gradeGroup][subject][unit];
        }
        
        // 참고 자료 읽기 (있는 경우)
        let referenceContent = '';
        const fileInput = document.getElementById('referenceFile');
        if (fileInput.files && fileInput.files.length > 0) {
            try {
                referenceContent = await readFileContent(fileInput.files[0]);
            } catch (error) {
                console.warn('파일 읽기 오류:', error);
                showErrorMessage(`파일 읽기 중 오류가 발생했습니다: ${error.message}`);
                referenceContent = '(파일 읽기 실패)';
            }
        }
        
        // 실험 정보 가져오기
        const experimentTopic = document.getElementById('experimentTopic').value || '(실험 주제 미지정)';
        const teacherIntent = document.getElementById('teacherIntent').value || '(수업 의도 미지정)';
        
        // 프롬프트 변수 설정
        const promptVariables = {
            schoolLevel,
            gradeGroup,
            subject,
            unit,
            contentElements: contentElements.join(', '),
            prerequisiteContent,
            experimentTopic,
            teacherIntent,
            referenceContent: referenceContent || '(참고 자료 없음)'
        };
        
        // 프롬프트 렌더링
        const experimentPrompt = renderTemplate(experimentDesignPrompt, promptVariables);
        debug('Generated experiment prompt:', experimentPrompt);
        
        // OpenAI API 호출로 실험 설계
        const messages = [{ role: 'user', content: experimentPrompt }];
        
        const experimentResultDiv = document.getElementById('experimentResult');
        experimentResultDiv.innerHTML = '';
        
        const experimentDesign = await callOpenAIService(messages, (chunk, fullText) => {
            experimentResultDiv.innerHTML = markdownToHtml(fullText);
        });
        
        state.currentExperiment = experimentDesign;
        
        // 학생용 보고서 템플릿 생성
        showLoading('학생용 보고서 템플릿을 생성하는 중입니다...');
        
        const reportPromptVariables = {
            experimentDesign
        };
        
        const reportPrompt = renderTemplate(studentReportTemplatePrompt, reportPromptVariables);
        const reportMessages = [{ role: 'user', content: reportPrompt }];
        
        const reportResultDiv = document.getElementById('reportResult');
        reportResultDiv.innerHTML = '';
        
        const reportTemplate = await callOpenAIService(reportMessages, (chunk, fullText) => {
            reportResultDiv.innerHTML = markdownToHtml(fullText);
        });
        
        state.currentReport = reportTemplate;
        
        // 결과 섹션 표시
        document.getElementById('outputSection').style.display = 'block';
        activateTab('experiment');
        
        // 결과 섹션 이벤트 리스너 설정
        setupResultEventListeners();
        
        // 스크롤
        document.getElementById('outputSection').scrollIntoView({ behavior: 'smooth' });
        
        hideLoading();
    } catch (error) {
        console.error('실험 설계 오류:', error);
        showErrorMessage(`실험 설계 중 오류가 발생했습니다: ${error.message}`);
        hideLoading();
    }
}

// 시뮬레이션 핸들러
async function handleSimulationClick() {
    if (!state.currentExperiment) {
        showErrorMessage('먼저 실험을 설계해주세요.');
        return;
    }
    
    try {
        showLoading('시뮬레이션을 생성하는 중입니다...');
        
        const promptVariables = {
            experimentDesign: state.currentExperiment
        };
        
        const prompt = renderTemplate(simulationPrompt, promptVariables);
        const messages = [{ role: 'user', content: prompt }];
        
        const simulationContent = document.getElementById('simulationContent');
        simulationContent.innerHTML = '';
        
        await callOpenAIService(messages, (chunk, fullText) => {
            simulationContent.innerHTML = markdownToHtml(fullText);
        });
        
        document.getElementById('simulationModal').style.display = 'flex';
        hideLoading();
    } catch (error) {
        console.error('시뮬레이션 생성 오류:', error);
        showErrorMessage(`시뮬레이션 생성 중 오류가 발생했습니다: ${error.message}`);
        hideLoading();
    }
}

// 수정 요청 핸들러
function handleRevisionClick() {
    if (!state.currentExperiment) {
        showErrorMessage('먼저 실험을 설계해주세요.');
        return;
    }
    
    document.getElementById('revisionModal').style.display = 'flex';
    document.getElementById('revisionRequest').value = '';
}

// 수정 제출 핸들러
async function handleSubmitRevision() {
    const revisionRequest = document.getElementById('revisionRequest').value.trim();
    
    if (!revisionRequest) {
        showErrorMessage('수정 요청 내용을 입력해주세요.');
        return;
    }
    
    try {
        // 모달 닫기
        closeModals();
        
        showLoading('실험 설계를 수정하는 중입니다...');
        
        // 프롬프트 변수 설정
        const promptVariables = {
            originalExperiment: state.currentExperiment,
            revisionRequest
        };
        
        // 프롬프트 렌더링
        const prompt = renderTemplate(experimentRevisionPrompt, promptVariables);
        
        // API 호출
        const messages = [{ role: 'user', content: prompt }];
        
        const experimentResultDiv = document.getElementById('experimentResult');
        experimentResultDiv.innerHTML = '';
        
        const revisedExperiment = await callOpenAIService(messages, (chunk, fullText) => {
            experimentResultDiv.innerHTML = markdownToHtml(fullText);
        });
        
        state.currentExperiment = revisedExperiment;
        
        // 보고서 템플릿 재생성
        showLoading('학생용 보고서 템플릿을 업데이트하는 중입니다...');
        
        const reportPromptVariables = {
            experimentDesign: revisedExperiment
        };
        
        const reportPrompt = renderTemplate(studentReportTemplatePrompt, reportPromptVariables);
        const reportMessages = [{ role: 'user', content: reportPrompt }];
        
        const reportResultDiv = document.getElementById('reportResult');
        reportResultDiv.innerHTML = '';
        
        const reportTemplate = await callOpenAIService(reportMessages, (chunk, fullText) => {
            reportResultDiv.innerHTML = markdownToHtml(fullText);
        });
        
        state.currentReport = reportTemplate;
        
        activateTab('experiment');
        hideLoading();
    } catch (error) {
        console.error('수정 오류:', error);
        showErrorMessage(`수정 중 오류가 발생했습니다: ${error.message}`);
        hideLoading();
    }
}

// YouTube 검색 필터 적용
async function handleFilterApply() {
    const filterInput = document.getElementById('topicFilter');
    const filter = filterInput.value.trim();
    
    if (filter === youtubeState.currentFilter) return;
    
    youtubeState.currentFilter = filter;
    youtubeState.currentPage = 1;
    youtubeState.searchResults = [];
    youtubeState.hasMoreResults = true;
    
    await searchYouTubeVideos();
}

// YouTube 비디오 검색
async function searchYouTubeVideos() {
    if (youtubeState.isLoading || !youtubeState.hasMoreResults) return;
    
    youtubeState.isLoading = true;
    showLoading('동영상을 검색하는 중...');
    
    try {
        const searchQuery = buildSearchQuery();
        const response = await fetch(`https://www.googleapis.com/youtube/v3/search?q=${encodeURIComponent(searchQuery)}&page=${youtubeState.currentPage}&key=AIzaSyB0000000000000000000000000000000`);
        const data = await response.json();
        
        if (data.videos && data.videos.length > 0) {
            youtubeState.searchResults.push(...data.videos);
            youtubeState.hasMoreResults = data.hasMore;
            renderVideoResults();
        } else {
            youtubeState.hasMoreResults = false;
        }
    } catch (error) {
        console.error('YouTube 검색 중 오류 발생:', error);
        showErrorMessage('동영상 검색 중 오류가 발생했습니다.');
    } finally {
        youtubeState.isLoading = false;
        hideLoading();
        }
}

// 검색 쿼리 생성
function buildSearchQuery() {
    const elements = state.selectedElements.join(' ');
    const topic = document.getElementById('experimentTopic').value;
    const filter = youtubeState.currentFilter;
    
    return `${elements} ${topic} ${filter}`.trim();
}

// 비디오 결과 렌더링
function renderVideoResults() {
    const container = document.getElementById('videoResults');
    container.innerHTML = '';
    
    youtubeState.searchResults.forEach(video => {
        const card = createVideoCard(video);
        container.appendChild(card);
    });
    
    // 더 보기 버튼 상태 업데이트
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    loadMoreBtn.style.display = youtubeState.hasMoreResults ? 'block' : 'none';
}

// 비디오 카드 생성
function createVideoCard(video) {
    const card = document.createElement('div');
    card.className = 'video-card';
    card.innerHTML = `
        <div class="video-thumbnail">
            <img src="${video.thumbnail}" alt="${video.title}">
        </div>
        <div class="video-info">
            <h3 class="video-title">${video.title}</h3>
            <div class="video-meta">
                <span>조회수: ${formatViewCount(video.viewCount)}</span>
                <span>${formatDate(video.publishedAt)}</span>
            </div>
        </div>
    `;
    
    card.addEventListener('click', () => {
        window.open(`https://www.youtube.com/watch?v=${video.videoId}`, '_blank');
    });
    
    return card;
        }

// 더 보기 버튼 처리
async function handleLoadMore() {
    youtubeState.currentPage++;
    await searchYouTubeVideos();
}

// 조회수 포맷팅
function formatViewCount(count) {
    if (count >= 1000000) {
        return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
        return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
}

// 날짜 포맷팅
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
    }
    
// 내보내기 핸들러 (HTML을 Word로 변환)
async function handleExport(type) {
    try {
        showLoading('Word 파일을 생성하는 중입니다...');
        
        const content = type === 'experiment' ? state.currentExperiment : state.currentReport;
        if (!content) {
            throw new Error('다운로드할 내용이 없습니다.');
        }

        // HTML 컨텐츠 생성
        const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <style>
                    body { font-family: 'Malgun Gothic', sans-serif; }
                    h1, h2, h3 { color: #4a6fa5; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; }
                    th { background-color: #f5f7fa; }
                </style>
            </head>
            <body>
                ${markdownToHtml(content)}
            </body>
            </html>
        `;

        // Blob 생성 및 다운로드
        const blob = new Blob([htmlContent], { type: 'application/msword' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${type === 'experiment' ? '실험설계안' : '학생용보고서'}.doc`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        hideLoading();
    } catch (error) {
        console.error('다운로드 오류:', error);
        showErrorMessage(`다운로드 중 오류가 발생했습니다: ${error.message}`);
        hideLoading();
    }
}

// 탭 활성화
function activateTab(tabName) {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabBtns.forEach(btn => btn.classList.remove('active'));
    tabContents.forEach(content => content.classList.remove('active'));
    
    document.querySelector(`.tab-btn[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(`${tabName}Tab`).classList.add('active');
}

// 로딩 표시
function showLoading(message = '처리 중입니다...') {
    const overlay = document.getElementById('loadingOverlay');
    const messageElement = document.getElementById('loadingMessage');
    
    messageElement.textContent = message;
    overlay.style.display = 'flex';
}

// 로딩 숨기기
function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    overlay.style.display = 'none';
}

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', init);