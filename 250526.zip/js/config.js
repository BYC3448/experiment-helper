// config.js

// 환경변수 값을 가져오는 함수
function getEnvValue(key, defaultValue = '') {
    // 실제 개발 환경에서는 환경변수에서 가져와야 합니다
    // 현재는 개발용으로 직접 입력
    const devValues = {
        OPENAI_API_KEY: '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', // 실제 API 키를 여기에 넣어주세요
        OPENAI_MODEL: 'gpt-4-turbo-preview'
    };
    
    return devValues[key] || defaultValue;
}

const config = {
    // OpenAI API 설정
    apiKey: getEnvValue('OPENAI_API_KEY'),
    apiModel: getEnvValue('OPENAI_MODEL', 'gpt-4-turbo-preview'),
    apiEndpoint: 'https://api.openai.com/v1/chat/completions',
    
    // 생성 설정
    maxTokens: 4000,
    temperature: 0.7,
    
    // 디버그 모드
    debugMode: true,
    
    // 스트리밍 설정
    useStreaming: true,
    
    // 지원 파일 형식
    supportedFileTypes: ['.pdf', '.docx', '.txt', '.md']
};

// 초기화 시 설정 검증
if (!config.apiKey || config.apiKey === 'sk-your_api_key_here') {
    console.warn('OpenAI API key가 설정되지 않았습니다. config.js에서 API key를 설정해주세요.');
}

export default config;